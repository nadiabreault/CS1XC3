/**
*@file student.h
*@author Sharmin Ahmed (Commented by Nadia Breault)
*@date 2022-04-08
*@brief student library for managing students, including student type definition and student functions.
*
*/ 

/**
*Student type stores a course with fields first_name,last_name, id, grades, and num_grades.
*
*/
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
