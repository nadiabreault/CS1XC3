/**
* @file course.c
*@author Sharmin Ahmed (Commented by Nadia Breault)
*@brief  These are a compilation of functions that will be used in main.c
*@version 0.1
*@date 2022-04-08
*/

#include "course.h"
#include <stdlib.h>
#include <stdio.h>



/**
 *@brief Adds a student to the provided course
 *
 *@param course
 *@param student
 *
 *@return nothing
 */
void enroll_student(Course *course, Student *student)
{
// adds one to the course and checks to see if this is the first student enrolled. If it is the it creates a type student for the one student in the class, using calloc.
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //if it is not the the first student in the class it used realloc to add more space to the student type and adds in the new student.
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
*@brief This funtion prints all the students in the course provided. And calls upon print student to print eachs students info.
*
*
*@param course
*@return nothing 
*/
void print_course(Course* course)
{
//Here it is printing all the course info
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //Then it is for looping for the amount of students in the class and calling upon print student to print the ith student in the class untill all the students are printed.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
*@brief This function finds the top student in the provided course.This function also calls upon the average function.
*
*
*@param course
*@return  student (The top student)
*/
Student* top_student(Course* course)
{
	//if there are no students in the class then it returns nothing
  if (course->total_students == 0) return NULL;
 // sets the max_average to the first student in the course then will search for the highest average by callin upon average.
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 //Loops through through all the students comparing it untill the current max and replaces it if the new students
//average is higher than the current untill all the student have benn checked.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
//returns the top student
  return student;
}
/**
*@brief This function finds the number of students who are passing a course. This function also calls upon the average function
*
*
*@param course
*@param total_passing
*@return total_passing
*/
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  //loops through all the students to see how many students are passing in the course.
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  //next, takes the count to create and new passing student type
  passing = calloc(count, sizeof(Student));
//Next loops again through all the students to add all the students who are passing to the new passing student type.
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;
// returns all the passing students.
  return passing;
}