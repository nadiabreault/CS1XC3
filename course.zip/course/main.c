/**
*@mainpage Student and course function demonstration 
*
*The Student and course function demonstration shows how multiple funtions in the course and student
* library work including:
* - enroll_student, enrolling a student in the cousre
* - generate-random_student
* - passing, check to see how man students habe passed a course
* - top_student
*
* @file main.c
*@author Sharmin Ahmed (Commented by Nadia Breault)
*@brief  This program creates a course and enrolls 20 students in it. As well as determines the top student, 
*and the amount of student passing the cousre.
*@ version 0.1
*@date 2022-04-08
*/

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));
//Creating a course called MATH 101, Basics of MAthematics
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

//enrolling 20 students into the course with 8 grades for each student.
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  //prints all the course info including all the student in it
  print_course(MATH101);

//finds the top student and prints the top student.
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

//finds all the passing students and prints them all.
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}