/**
* @file student.c
*@author Sharmin Ahmed (Commented by Nadia Breault)
*@breif  These are a compilation of functions that will be used in main.c realating to the student
*@ version 1.0
*@date 2022-04-08
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 *@breif Adds a grade to the desired student. This function also calls upon the average funtion. 
 *
 *@param grade
 *@param student
 *
 *@return nothing
 */
void add_grade(Student* student, double grade)
{
//checks too see how many grades need to be added and if it is only one then it uses calloc to create a grade for type student of size 1.
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  
  // if it larger than 1, it uses rellac to allocate grades to the student of size grade.
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}
// gets the average for that student for that class.
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  
  // Uses a for loop to add in the grade for that student.
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 *@breif prints the desired student and all of there info.
 *
 *@param student
 *
 *@return nothing
 */
void print_student(Student* student)
{
	//printing all of the info of the disired student for the type student.
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // loops for the amount of grades this student has and prints them all.
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 *@breif This function generates a random student and creates a name, id, and a random grades for the grades amount of classes they are enrolled in.
 *
 *@param grades
 *
 *@return new student
 */
Student* generate_random_student(int grades)
{
	// these are a bunch of first and last names to chose from
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 //creates a new student type for this new student
  Student *new_student = calloc(1, sizeof(Student));
//creates a first and last name.
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);
// creats a id of length 10 for this new student.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';
//add 'grades' amount of grades for this student, chosen by the parameter.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}