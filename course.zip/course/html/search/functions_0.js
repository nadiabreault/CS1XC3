var searchData=
[
  ['add_5fgrade_24',['add_grade',['../student_8c.html#a1ee4302d01d8908db57e238f5f9dd9f5',1,'add_grade(Student *student, double grade):&#160;student.c'],['../student_8h.html#a1ee4302d01d8908db57e238f5f9dd9f5',1,'add_grade(Student *student, double grade):&#160;student.c']]]
];
